package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.DoseLogEntity
import com.example.data.entity.MedicineEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.AdherenceGrade
import com.example.viewmodel.SugarTrackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicinesScreen(viewModel: SugarTrackViewModel) {
    val medicines by viewModel.medicines.collectAsState()
    val lowStockMeds by viewModel.lowStockMedicines.collectAsState()
    val doseLogs by viewModel.doseLogs.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()

    var selectedScreenTab by remember { mutableStateOf(0) } // 0 = Schedule, 1 = Taken History & Adherence
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    var adherencePeriod by remember { mutableStateOf("Weekly") } // "Daily", "Weekly", "Monthly"
    var doseLogStatusFilter by remember { mutableStateOf("All") } // "All", "ON_TIME", "LATE", "MISSED"
    val categories = listOf("All", "Tablet", "Capsule", "Insulin", "Injection", "Syrup", "Drops")

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingMedicine by remember { mutableStateOf<MedicineEntity?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<MedicineEntity?>(null) }
    var viewingMedicineDetail by remember { mutableStateOf<MedicineEntity?>(null) }

    val filteredMedicines = remember(medicines, selectedCategoryFilter) {
        if (selectedCategoryFilter == "All") medicines
        else medicines.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Medicine Management",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 22.sp else 19.sp,
                        color = MedicalBluePrimary
                    )
                },
                actions = {
                    IconButton(
                        onClick = {
                            editingMedicine = null
                            showAddEditDialog = true
                        },
                        modifier = Modifier.testTag("add_medicine_button")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Medicine", tint = MedicalBluePrimary, modifier = Modifier.size(28.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            if (selectedScreenTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editingMedicine = null
                        showAddEditDialog = true
                    },
                    containerColor = MedicalBluePrimary,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Add Medicine", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("fab_add_medicine")
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Screen Tabs
            TabRow(
                selectedTabIndex = selectedScreenTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MedicalBluePrimary
            ) {
                Tab(
                    selected = selectedScreenTab == 0,
                    onClick = { selectedScreenTab = 0 },
                    text = {
                        Text(
                            "Daily Schedule (${medicines.size})",
                            fontWeight = if (selectedScreenTab == 0) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (isSenior) 15.sp else 13.sp
                        )
                    }
                )
                Tab(
                    selected = selectedScreenTab == 1,
                    onClick = { selectedScreenTab = 1 },
                    text = {
                        Text(
                            "Taken History & Adherence",
                            fontWeight = if (selectedScreenTab == 1) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (isSenior) 15.sp else 13.sp
                        )
                    }
                )
            }

            if (selectedScreenTab == 0) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 10.dp, bottom = 88.dp)
                ) {
                    // Category Filter Chips
                    item {
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(categories) { cat ->
                                FilterChip(
                                    selected = selectedCategoryFilter == cat,
                                    onClick = { selectedCategoryFilter = cat },
                                    label = { Text(cat, fontSize = if (isSenior) 14.sp else 12.sp) }
                                )
                            }
                        }
                    }

                    // Low Stock Refill Warning Section
                    if (lowStockMeds.isNotEmpty()) {
                        item {
                            Text(
                                "Stock & Refill Alerts",
                                fontWeight = FontWeight.Bold,
                                color = SugarHighAlertOrange,
                                fontSize = if (isSenior) 16.sp else 13.sp
                            )
                        }
                        items(lowStockMeds) { med ->
                            RefillAlertCard(
                                medicineName = med.name,
                                stockLeft = med.quantityAvailable,
                                onRefillClick = { viewModel.refillMedicine(med, 30) }
                            )
                        }
                    }

                    // Medicine List
                    item {
                        Text(
                            "All Scheduled Medicines (${filteredMedicines.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 18.sp else 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (filteredMedicines.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("No medicines found under '$selectedCategoryFilter'. Tap '+' to add one.")
                                }
                            }
                        }
                    } else {
                        items(filteredMedicines, key = { it.id }) { med ->
                            MedicineDetailCard(
                                medicine = med,
                                isSenior = isSenior,
                                onCardClick = { viewingMedicineDetail = med },
                                onTaken = { viewModel.markMedicineTaken(med) },
                                onSnooze = { viewModel.snoozeMedicine(med, 15) },
                                onMissed = { viewModel.markMedicineMissed(med) },
                                onEdit = {
                                    editingMedicine = med
                                    showAddEditDialog = true
                                },
                                onDelete = { showDeleteConfirmDialog = med },
                                onRefill = { viewModel.refillMedicine(med, 30) },
                                onTestReminder = { viewModel.testReminderNotification(med) }
                            )
                        }
                    }
                }
            } else {
                // Tab 1: Medication Adherence Score & Dose History
                val summary = remember(adherencePeriod, medicines, doseLogs) {
                    viewModel.getAdherenceSummary(adherencePeriod, medicines, doseLogs)
                }

                val filteredLogs = remember(doseLogs, doseLogStatusFilter) {
                    if (doseLogStatusFilter == "All") doseLogs
                    else doseLogs.filter { it.status.equals(doseLogStatusFilter, ignoreCase = true) }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 14.dp, bottom = 88.dp)
                ) {
                    // 1. Period Selector: Daily Score, Weekly Score, Monthly Score
                    item {
                        val periods = listOf(
                            Pair("Daily", "Daily Score"),
                            Pair("Weekly", "Weekly Score"),
                            Pair("Monthly", "Monthly Score")
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            periods.forEach { (key, displayTitle) ->
                                val isSelected = adherencePeriod.equals(key, ignoreCase = true)
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                                    shadowElevation = if (isSelected) 2.dp else 0.dp,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { adherencePeriod = key }
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(vertical = if (isSenior) 10.dp else 8.dp)
                                    ) {
                                        Text(
                                            text = displayTitle,
                                            fontSize = if (isSenior) 14.sp else 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MedicalBluePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. Main Adherence Score Card
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_medication_adherence_score"),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (summary.grade) {
                                                        AdherenceGrade.EXCELLENT -> Color(0xFFDCFCE7)
                                                        AdherenceGrade.GOOD -> Color(0xFFDBEAFE)
                                                        AdherenceGrade.FAIR -> Color(0xFFFEF3C7)
                                                        AdherenceGrade.POOR -> Color(0xFFFEE2E2)
                                                    }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircleOutline,
                                                contentDescription = null,
                                                tint = when (summary.grade) {
                                                    AdherenceGrade.EXCELLENT -> SugarNormalGreen
                                                    AdherenceGrade.GOOD -> MedicalBluePrimary
                                                    AdherenceGrade.FAIR -> SugarHighAlertOrange
                                                    AdherenceGrade.POOR -> SugarLowAlertRed
                                                },
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Medication Adherence",
                                                fontSize = if (isSenior) 22.sp else 18.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "$adherencePeriod Score Assessment",
                                                fontSize = 12.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }

                                    AdherenceGradeBadge(grade = summary.grade, isSenior = isSenior)
                                }

                                Spacer(Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "${summary.score}%",
                                            fontSize = if (isSenior) 52.sp else 44.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = when (summary.grade) {
                                                AdherenceGrade.EXCELLENT -> SugarNormalGreen
                                                AdherenceGrade.GOOD -> MedicalBluePrimary
                                                AdherenceGrade.FAIR -> SugarHighAlertOrange
                                                AdherenceGrade.POOR -> SugarLowAlertRed
                                            }
                                        )
                                        Text(
                                            text = "${summary.grade.displayTitle}",
                                            fontSize = if (isSenior) 17.sp else 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Breakdown chips: Taken on time, late, missed
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Color(0xFFDCFCE7)
                                        ) {
                                            Text(
                                                text = "✓ Taken On-Time: ${summary.takenOnTimeCount}",
                                                fontSize = if (isSenior) 14.sp else 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SugarNormalGreen,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Color(0xFFFEF3C7)
                                        ) {
                                            Text(
                                                text = "⏰ Late: ${summary.lateCount}",
                                                fontSize = if (isSenior) 14.sp else 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SugarHighAlertOrange,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (summary.missedCount > 0) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = "✕ Missed: ${summary.missedCount}",
                                                fontSize = if (isSenior) 14.sp else 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (summary.missedCount > 0) SugarLowAlertRed else Color.Gray,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(Modifier.height(14.dp))

                                Text(
                                    text = summary.grade.description,
                                    fontSize = if (isSenior) 15.sp else 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = if (isSenior) 22.sp else 18.sp
                                )

                                Spacer(Modifier.height(14.dp))

                                // Adherence standard tiers (90-100, 75-89, 50-74, Below 50)
                                AdherenceTiersDisplay(isSenior = isSenior)
                            }
                        }
                    }

                    // 3. Adherence Score Calculation Guide Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "📐 How Adherence Score is Calculated",
                                    fontSize = if (isSenior) 17.sp else 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = "• Taken On-Time: 100% full adherence credit\n• Taken Late: 50% partial credit (delay recorded)\n• Missed: 0% credit (high spike risk)\nFormula: (On-Time × 100 + Late × 50 + Missed × 0) ÷ Total Doses",
                                    fontSize = if (isSenior) 14.sp else 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    // 4. Charts and Trends Section
                    item {
                        AdherenceTrendChart(
                            points = summary.trendPoints,
                            heightDp = if (isSenior) 175 else 150,
                            isSenior = isSenior
                        )
                    }

                    // 5. Today's Medicine Quick Intake Actions
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Today's Schedule & Intake",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 19.sp else 16.sp
                            )
                            Text(
                                "${medicines.count { it.takenToday }} of ${medicines.size} Completed",
                                fontSize = 12.sp,
                                color = SugarNormalGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    items(medicines, key = { "today_${it.id}" }) { med ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    med.takenToday && !med.lateToday -> SugarNormalGreen.copy(alpha = 0.15f)
                                                    med.lateToday -> SugarHighAlertOrange.copy(alpha = 0.15f)
                                                    med.missedToday -> SugarLowAlertRed.copy(alpha = 0.15f)
                                                    else -> Color.LightGray.copy(alpha = 0.3f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when {
                                                med.takenToday -> Icons.Default.CheckCircle
                                                med.lateToday -> Icons.Default.AccessTime
                                                med.missedToday -> Icons.Default.Cancel
                                                else -> Icons.Default.Schedule
                                            },
                                            contentDescription = null,
                                            tint = when {
                                                med.takenToday && !med.lateToday -> SugarNormalGreen
                                                med.lateToday -> SugarHighAlertOrange
                                                med.missedToday -> SugarLowAlertRed
                                                else -> Color.Gray
                                            },
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            med.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = if (isSenior) 17.sp else 15.sp
                                        )
                                        Text(
                                            "${med.dosage} • ⏰ ${med.reminderTime}",
                                            fontSize = if (isSenior) 13.sp else 12.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = { viewModel.markMedicineTaken(med) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (med.takenToday && !med.lateToday) SugarNormalGreenBg else MaterialTheme.colorScheme.surfaceVariant,
                                            contentColor = if (med.takenToday && !med.lateToday) SugarNormalGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("✓ Taken", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.markMedicineLate(med) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(36.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = if (med.lateToday) SugarHighAlertOrange else Color.Gray
                                        )
                                    ) {
                                        Text("⏰ Late", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // 6. Dose History Logs Header & Filters
                    item {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Historical Dose Logs (${filteredLogs.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = if (isSenior) 19.sp else 16.sp
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(listOf("All", "ON_TIME", "LATE", "MISSED")) { statusFilter ->
                                    val count = when (statusFilter) {
                                        "All" -> doseLogs.size
                                        else -> doseLogs.count { it.status.equals(statusFilter, ignoreCase = true) }
                                    }
                                    val label = when (statusFilter) {
                                        "All" -> "All ($count)"
                                        "ON_TIME" -> "✓ On-Time ($count)"
                                        "LATE" -> "⏰ Late ($count)"
                                        "MISSED" -> "✕ Missed ($count)"
                                        else -> statusFilter
                                    }
                                    FilterChip(
                                        selected = doseLogStatusFilter == statusFilter,
                                        onClick = { doseLogStatusFilter = statusFilter },
                                        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                                    )
                                }
                            }
                        }
                    }

                    // 7. Dose Logs List
                    if (filteredLogs.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No dose logs found under '$doseLogStatusFilter'.",
                                        color = Color.Gray,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    } else {
                        items(filteredLogs.take(30), key = { it.id }) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = CircleShape,
                                            color = when (log.status) {
                                                "ON_TIME" -> Color(0xFFDCFCE7)
                                                "LATE" -> Color(0xFFFEF3C7)
                                                else -> Color(0xFFFEE2E2)
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = when (log.status) {
                                                        "ON_TIME" -> Icons.Default.Check
                                                        "LATE" -> Icons.Default.AccessTime
                                                        else -> Icons.Default.Close
                                                    },
                                                    contentDescription = null,
                                                    tint = when (log.status) {
                                                        "ON_TIME" -> SugarNormalGreen
                                                        "LATE" -> SugarHighAlertOrange
                                                        else -> SugarLowAlertRed
                                                    },
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }

                                        Spacer(Modifier.width(10.dp))

                                        Column {
                                            Text(
                                                text = log.medicineName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = if (isSenior) 16.sp else 14.sp
                                            )
                                            Text(
                                                text = "${log.dosage} • ${log.date} at ${log.scheduledTime}",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = when (log.status) {
                                            "ON_TIME" -> Color(0xFFDCFCE7)
                                            "LATE" -> Color(0xFFFEF3C7)
                                            else -> Color(0xFFFEE2E2)
                                        }
                                    ) {
                                        Text(
                                            text = when (log.status) {
                                                "ON_TIME" -> "On-Time ✓"
                                                "LATE" -> "Late ⏰"
                                                else -> "Missed ✕"
                                            },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (log.status) {
                                                "ON_TIME" -> SugarNormalGreen
                                                "LATE" -> SugarHighAlertOrange
                                                else -> SugarLowAlertRed
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Medicine Detail Screen Dialog
    viewingMedicineDetail?.let { med ->
        MedicineDetailDialog(
            medicine = med,
            isSenior = isSenior,
            onDismiss = { viewingMedicineDetail = null },
            onTaken = {
                viewModel.markMedicineTaken(med)
                viewingMedicineDetail = null
            },
            onSnooze = {
                viewModel.snoozeMedicine(med, 15)
                viewingMedicineDetail = null
            },
            onMissed = {
                viewModel.markMedicineMissed(med)
                viewingMedicineDetail = null
            },
            onRefill = {
                viewModel.refillMedicine(med, 30)
                viewingMedicineDetail = null
            },
            onEdit = {
                viewingMedicineDetail = null
                editingMedicine = med
                showAddEditDialog = true
            }
        )
    }

    // Add / Edit Dialog
    if (showAddEditDialog) {
        AddEditMedicineDialog(
            existing = editingMedicine,
            onDismiss = { showAddEditDialog = false },
            onSave = { updated ->
                if (editingMedicine == null) {
                    viewModel.addMedicine(updated)
                } else {
                    viewModel.updateMedicine(updated)
                }
                showAddEditDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    showDeleteConfirmDialog?.let { med ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Medicine") },
            text = { Text("Are you sure you want to remove ${med.name} from your schedule?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMedicine(med)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SugarLowAlertRed)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun MedicineDetailCard(
    medicine: MedicineEntity,
    isSenior: Boolean,
    onCardClick: () -> Unit,
    onTaken: () -> Unit,
    onSnooze: () -> Unit,
    onMissed: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRefill: () -> Unit,
    onTestReminder: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onCardClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Name, Category Tag, Overflow menu/edit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(if (isSenior) 44.dp else 36.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (medicine.category) {
                                "Insulin" -> Icons.Default.Vaccines
                                "Syrup" -> Icons.Default.LocalDrink
                                else -> Icons.Default.Medication
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(if (isSenior) 24.dp else 20.dp)
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    Column {
                        Text(
                            text = medicine.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 19.sp else 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${medicine.dosage} • ${medicine.category}",
                                fontSize = if (isSenior) 14.sp else 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Row {
                    IconButton(onClick = onTestReminder, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Outlined.Notifications, contentDescription = "Test Notification", tint = MedicalBlueLight)
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.Gray)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = SugarLowAlertRed)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Details info row: Frequency & Stock Available
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${medicine.reminderTime} (${medicine.frequency})",
                        fontSize = if (isSenior) 14.sp else 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Stock pill
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Stock: ${medicine.quantityAvailable} left",
                        fontSize = if (isSenior) 14.sp else 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (medicine.quantityAvailable <= medicine.refillThreshold) SugarHighAlertOrange else SugarNormalGreen
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = onRefill, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Refill", tint = MedicalBluePrimary)
                    }
                }
            }

            if (medicine.notes.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Note: ${medicine.notes}",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }

            Spacer(Modifier.height(12.dp))

            // Action Buttons: Mark Taken / Snooze / Missed
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onTaken,
                    modifier = Modifier.weight(1.2f).height(if (isSenior) 48.dp else 40.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (medicine.takenToday) SugarNormalGreen else MedicalBluePrimary
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (medicine.takenToday) "Taken ✓" else "Take", fontSize = if (isSenior) 14.sp else 12.sp)
                }

                OutlinedButton(
                    onClick = onSnooze,
                    modifier = Modifier.weight(1f).height(if (isSenior) 48.dp else 40.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MedicalBlueLight),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("Snooze", fontSize = if (isSenior) 13.sp else 11.sp)
                }

                OutlinedButton(
                    onClick = onMissed,
                    modifier = Modifier.weight(0.9f).height(if (isSenior) 48.dp else 40.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (medicine.missedToday) SugarLowAlertRed else Color.Gray
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (medicine.missedToday) "Missed ✕" else "Miss", fontSize = if (isSenior) 13.sp else 11.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMedicineDialog(
    existing: MedicineEntity?,
    onDismiss: () -> Unit,
    onSave: (MedicineEntity) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var dosage by remember { mutableStateOf(existing?.dosage ?: "500 mg") }
    var frequency by remember { mutableStateOf(existing?.frequency ?: "Once Daily") }
    var category by remember { mutableStateOf(existing?.category ?: "Tablet") }
    var mealTiming by remember { mutableStateOf("After Food") }
    var quantityStr by remember { mutableStateOf(existing?.quantityAvailable?.toString() ?: "30") }
    var reminderTime by remember { mutableStateOf(existing?.reminderTime ?: "08:00 AM") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    val categories = listOf("Tablet", "Capsule", "Insulin", "Injection", "Syrup", "Drops")
    val frequencies = listOf("Once Daily", "Twice Daily", "Thrice Daily", "As Needed")
    val timings = listOf("Before Food", "After Food", "With Food", "Empty Stomach", "Bedtime")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (existing == null) "Add New Medicine" else "Edit Medicine", fontWeight = FontWeight.Bold)
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Medicine Name (e.g. Metformin)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_medicine_name"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dosage,
                            onValueChange = { dosage = it },
                            label = { Text("Dosage (e.g. 500mg, 10 units)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text("Stock Quantity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    Text("Type / Form:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Text("Frequency:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(frequencies) { freq ->
                            FilterChip(
                                selected = frequency == freq,
                                onClick = { frequency = freq },
                                label = { Text(freq, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Text("Meal Timing:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(timings) { timeOpt ->
                            FilterChip(
                                selected = mealTiming == timeOpt,
                                onClick = { mealTiming = timeOpt },
                                label = { Text(timeOpt, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = reminderTime,
                        onValueChange = { reminderTime = it },
                        label = { Text("Reminder Time (e.g. 08:00 AM)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Doctor's notes / instructions") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val combinedNotes = if (notes.isBlank()) mealTiming else "$mealTiming • $notes"
                        val entity = existing?.copy(
                            name = name,
                            dosage = dosage,
                            frequency = frequency,
                            category = category,
                            quantityAvailable = quantityStr.toIntOrNull() ?: 30,
                            reminderTime = reminderTime,
                            notes = combinedNotes
                        ) ?: MedicineEntity(
                            name = name,
                            dosage = dosage,
                            frequency = frequency,
                            category = category,
                            quantityAvailable = quantityStr.toIntOrNull() ?: 30,
                            reminderTime = reminderTime,
                            startDate = "Today",
                            notes = combinedNotes
                        )
                        onSave(entity)
                    }
                },
                modifier = Modifier.testTag("save_medicine_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun MedicineDetailDialog(
    medicine: MedicineEntity,
    isSenior: Boolean,
    onDismiss: () -> Unit,
    onTaken: () -> Unit,
    onSnooze: () -> Unit,
    onMissed: () -> Unit,
    onRefill: () -> Unit,
    onEdit: () -> Unit
) {
    val isLowStock = medicine.quantityAvailable <= medicine.refillThreshold

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (medicine.category) {
                                "Insulin" -> Icons.Default.Vaccines
                                "Syrup" -> Icons.Default.LocalDrink
                                else -> Icons.Default.Medication
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = medicine.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 22.sp else 18.sp
                        )
                        Text(
                            text = "${medicine.dosage} • ${medicine.category}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Medicine", tint = MedicalBlueLight)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Next Reminder Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Alarm,
                            contentDescription = null,
                            tint = MedicalBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Scheduled Reminder", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                text = "${medicine.reminderTime} • ${medicine.frequency}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MedicalBluePrimary
                            )
                        }
                    }
                }

                // Remaining Quantity & Refill Alert
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isLowStock) SugarHighAlertOrangeBg else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Remaining Stock",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = if (isLowStock) SugarHighAlertOrange else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${medicine.quantityAvailable} doses left",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isLowStock) SugarHighAlertOrange else SugarNormalGreen
                                )
                                Spacer(Modifier.width(8.dp))
                                Button(
                                    onClick = onRefill,
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary)
                                ) {
                                    Text("+30 Refill", fontSize = 11.sp)
                                }
                            }
                        }

                        if (isLowStock) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "⚠️ Low stock alert! Quantity reached alert threshold (${medicine.refillThreshold} doses). Please refill soon.",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Instructions & Doctor Notes
                if (medicine.notes.isNotBlank()) {
                    Column {
                        Text("Instructions / Doctor Notes", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = medicine.notes,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                // Dose Actions: Taken, Snooze, Missed
                Text("Log Dose Action:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onTaken,
                        modifier = Modifier.weight(1.2f).height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (medicine.takenToday) SugarNormalGreen else MedicalBluePrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (medicine.takenToday) "Taken ✓" else "Taken")
                    }

                    OutlinedButton(
                        onClick = onSnooze,
                        modifier = Modifier.weight(1f).height(44.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MedicalBlueLight),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("Snooze")
                    }

                    OutlinedButton(
                        onClick = onMissed,
                        modifier = Modifier.weight(0.9f).height(44.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (medicine.missedToday) SugarLowAlertRed else Color.Gray
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(if (medicine.missedToday) "Missed ✕" else "Miss")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
