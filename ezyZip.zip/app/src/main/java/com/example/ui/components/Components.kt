package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.SugarLogEntity
import com.example.ui.theme.*
import com.example.viewmodel.AdherenceGrade
import com.example.viewmodel.DayAdherencePoint

@Composable
fun AdherenceGradeBadge(grade: AdherenceGrade, isSenior: Boolean = false) {
    val (bg, fg) = when (grade) {
        AdherenceGrade.EXCELLENT -> Pair(Color(0xFFDCFCE7), SugarNormalGreen)
        AdherenceGrade.GOOD -> Pair(Color(0xFFDBEAFE), MedicalBluePrimary)
        AdherenceGrade.FAIR -> Pair(Color(0xFFFEF3C7), SugarHighAlertOrange)
        AdherenceGrade.POOR -> Pair(Color(0xFFFEE2E2), SugarLowAlertRed)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg
    ) {
        Text(
            text = "${grade.displayRange} ${grade.label}",
            color = fg,
            fontWeight = FontWeight.ExtraBold,
            fontSize = if (isSenior) 14.sp else 12.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun AdherenceTiersDisplay(isSenior: Boolean = false) {
    val tiers = listOf(
        Triple("90-100", "Excellent", SugarNormalGreen),
        Triple("75-89", "Good", MedicalBluePrimary),
        Triple("50-74", "Fair", SugarHighAlertOrange),
        Triple("Below 50", "Poor", SugarLowAlertRed)
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tiers.forEach { (range, title, color) ->
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                color = color.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f))
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = range,
                        fontSize = if (isSenior) 13.sp else 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = color
                    )
                    Text(
                        text = title,
                        fontSize = if (isSenior) 12.sp else 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = color
                    )
                }
            }
        }
    }
}

@Composable
fun AdherenceTrendChart(
    points: List<DayAdherencePoint>,
    modifier: Modifier = Modifier,
    heightDp: Int = 180,
    isSenior: Boolean = false
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📈 Adherence Trend & Doses",
                    fontSize = if (isSenior) 17.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Goal: ≥ 90%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SugarNormalGreen
                )
            }

            Spacer(Modifier.height(12.dp))

            // Bars Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(heightDp.dp)
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                points.forEach { point ->
                    val barColor = when {
                        point.score >= 90 -> SugarNormalGreen
                        point.score >= 75 -> MedicalBluePrimary
                        point.score >= 50 -> SugarHighAlertOrange
                        else -> SugarLowAlertRed
                    }

                    val heightFraction = (point.score / 100f).coerceIn(0.12f, 1f)

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        // Score Text on top of bar
                        Text(
                            text = "${point.score}%",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = barColor
                        )

                        Spacer(Modifier.height(4.dp))

                        // Rounded bar
                        Box(
                            modifier = Modifier
                                .width(if (points.size <= 4) 34.dp else 22.dp)
                                .fillMaxHeight(heightFraction * 0.78f)
                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                .background(barColor)
                        )

                        Spacer(Modifier.height(6.dp))

                        // Day / Week Label
                        Text(
                            text = point.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Clinical Standard Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SugarNormalGreen))
                    Spacer(Modifier.width(4.dp))
                    Text("90-100 Excellent", fontSize = 10.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(MedicalBluePrimary))
                    Spacer(Modifier.width(4.dp))
                    Text("75-89 Good", fontSize = 10.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SugarHighAlertOrange))
                    Spacer(Modifier.width(4.dp))
                    Text("50-74 Fair", fontSize = 10.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SugarLowAlertRed))
                    Spacer(Modifier.width(4.dp))
                    Text("Below 50 Poor", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun GlucoseStatusBadge(value: Double, isSenior: Boolean = false) {
    val (status, bg, fg) = when {
        value < 70 -> Triple("Low (Hypo)", SugarLowAlertRedBg, SugarLowAlertRed)
        value <= 140 -> Triple("Normal (In Target)", SugarNormalGreenBg, SugarNormalGreen)
        value <= 180 -> Triple("Elevated", SugarHighAlertOrangeBg, SugarHighAlertOrange)
        else -> Triple("High (Hyper)", Color(0xFFFFEBEE), SugarVeryHighAlertRed)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .padding(horizontal = if (isSenior) 12.dp else 8.dp, vertical = if (isSenior) 6.dp else 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = status,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = if (isSenior) 14.sp else 11.sp
        )
    }
}

@Composable
fun GlucoseTrendChart(
    logs: List<SugarLogEntity>,
    modifier: Modifier = Modifier,
    heightDp: Int = 180
) {
    if (logs.isEmpty()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .height(heightDp.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No sugar readings logged yet for this range",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        return
    }

    // Sort chronologically
    val sorted = logs.sortedBy { it.timestamp }.takeLast(10)
    val values = sorted.map { it.value.toFloat() }
    val minVal = (values.minOrNull() ?: 70f).coerceAtMost(60f)
    val maxVal = (values.maxOrNull() ?: 180f).coerceAtLeast(220f)
    val range = (maxVal - minVal).coerceAtLeast(10f)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(heightDp.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(SugarNormalGreen)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Target: 70 - 140 mg/dL",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    "${sorted.size} readings",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(8.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                val w = size.width
                val h = size.height

                // Target Zone Background (70 to 140)
                val targetTopY = h - ((140f - minVal) / range) * h
                val targetBottomY = h - ((70f - minVal) / range) * h
                drawRect(
                    color = SugarNormalGreenBg.copy(alpha = 0.45f),
                    topLeft = Offset(0f, targetTopY),
                    size = androidx.compose.ui.geometry.Size(w, (targetBottomY - targetTopY).coerceAtLeast(10f))
                )

                // Target boundary lines
                drawLine(
                    color = SugarNormalGreen.copy(alpha = 0.6f),
                    start = Offset(0f, targetTopY),
                    end = Offset(w, targetTopY),
                    strokeWidth = 2f
                )
                drawLine(
                    color = SugarNormalGreen.copy(alpha = 0.6f),
                    start = Offset(0f, targetBottomY),
                    end = Offset(w, targetBottomY),
                    strokeWidth = 2f
                )

                if (values.size > 1) {
                    val stepX = w / (values.size - 1)
                    val points = values.mapIndexed { idx, v ->
                        val x = idx * stepX
                        val y = h - ((v - minVal) / range) * h
                        Offset(x, y)
                    }

                    // Draw connecting line
                    val path = Path().apply {
                        moveTo(points[0].x, points[0].y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }
                    drawPath(
                        path = path,
                        color = Color(0xFF0D47A1),
                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                    )

                    // Draw points
                    for ((idx, p) in points.withIndex()) {
                        val v = values[idx]
                        val dotColor = when {
                            v < 70f -> SugarLowAlertRed
                            v <= 140f -> SugarNormalGreen
                            v <= 180f -> SugarHighAlertOrange
                            else -> SugarVeryHighAlertRed
                        }
                        drawCircle(color = Color.White, radius = 7f, center = p)
                        drawCircle(color = dotColor, radius = 5f, center = p)
                    }
                } else if (values.size == 1) {
                    val p = Offset(w / 2, h / 2)
                    drawCircle(color = Color(0xFF0D47A1), radius = 6f, center = p)
                }
            }

            // Labels row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                sorted.firstOrNull()?.let {
                    Text(it.date.takeLast(5), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                sorted.lastOrNull()?.let {
                    Text(it.date.takeLast(5), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun RefillAlertCard(
    medicineName: String,
    stockLeft: Int,
    onRefillClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Refill Alert",
                    tint = SugarHighAlertOrange,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Refill Needed: $medicineName",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFBF360C),
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Only $stockLeft doses remaining in stock",
                        color = Color(0xFFE65100),
                        fontSize = 12.sp
                    )
                }
            }

            Button(
                onClick = onRefillClick,
                colors = ButtonDefaults.buttonColors(containerColor = SugarHighAlertOrange),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("+30 Refill", fontSize = 12.sp, color = Color.White)
            }
        }
    }
}

@Composable
fun AdMobBannerSimulation(
    isPremium: Boolean,
    modifier: Modifier = Modifier
) {
    if (isPremium) return // Ads removed for Premium subscribers

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF0F4F8))
            .border(1.dp, Color(0xFFD6E2EE), RoundedCornerShape(8.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFFFB300))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text("Ad", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "Diabetic Care Pharmacy - Get 20% off test strips. AdMob Partner",
                fontSize = 11.sp,
                color = Color(0xFF455A64),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun EmergencyCallDialog(
    doctorName: String,
    doctorPhone: String,
    emergencyName: String,
    emergencyPhone: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = SugarLowAlertRed)
                Spacer(Modifier.width(8.dp))
                Text("Emergency Contacts", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Quickly connect with your physician or designated emergency family caregiver:",
                    style = MaterialTheme.typography.bodyMedium
                )

                // Call Doctor
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$doctorPhone"))
                        context.startActivity(intent)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary)
                ) {
                    Icon(Icons.Default.MedicalServices, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Call $doctorName ($doctorPhone)", fontSize = 13.sp)
                }

                // Call Caregiver
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$emergencyPhone"))
                        context.startActivity(intent)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Person, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Call $emergencyName ($emergencyPhone)", fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
