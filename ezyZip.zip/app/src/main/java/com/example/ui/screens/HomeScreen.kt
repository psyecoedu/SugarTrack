package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.MedicineEntity
import com.example.data.entity.SugarLogEntity
import com.example.data.entity.DoseLogEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.StringsLocalizer
import com.example.viewmodel.AdherenceGrade
import com.example.viewmodel.AdherenceScoreSummary
import com.example.viewmodel.DayAdherencePoint
import com.example.viewmodel.SugarTrackViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: SugarTrackViewModel,
    onNavigateToMedicines: () -> Unit,
    onNavigateToSugarLogs: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val profile by viewModel.userProfile.collectAsState()
    val medicines by viewModel.medicines.collectAsState()
    val lowStockMeds by viewModel.lowStockMedicines.collectAsState()
    val doseLogs by viewModel.doseLogs.collectAsState()
    val sugarLogs by viewModel.sugarLogs.collectAsState()
    val latestSugar by viewModel.latestSugarLog.collectAsState()
    val latestHba1c by viewModel.latestHbA1c.collectAsState()
    val appointments by viewModel.appointments.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()
    val lang by viewModel.appLanguage.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val waterGlasses by viewModel.waterGlasses.collectAsState()
    val dailySteps by viewModel.dailySteps.collectAsState()

    var showAddSugarDialog by remember { mutableStateOf(false) }
    var showEmergencyDialog by remember { mutableStateOf(false) }
    var showSelectMedDialog by remember { mutableStateOf(false) }
    var selectedSugarSlot by remember { mutableStateOf("Fasting") }

    // Next medicine due calculation
    val pendingMedicines = medicines.filter { !it.takenToday }
    val nextMedicine = pendingMedicines.minByOrNull { it.reminderHour * 60 + it.reminderMinute }
        ?: medicines.firstOrNull()

    // Adherence Calculation
    val totalMedsToday = medicines.size
    val takenMedsToday = medicines.count { it.takenToday }
    val adherencePercent = if (totalMedsToday > 0) {
        ((takenMedsToday.toDouble() / totalMedsToday) * 100).toInt()
    } else {
        100
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    SugarTrackPrimaryLogo(
                        iconSize = if (isSenior) 40.dp else 34.dp,
                        showTagline = true
                    )
                },
                actions = {
                    // Senior / Large Text Mode Toggle Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSenior) Color(0xFFFFD54F) else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clickable { viewModel.toggleSeniorMode(!isSenior) }
                            .testTag("toggle_senior_mode")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (isSenior) Icons.Default.AccessibilityNew else Icons.Outlined.Elderly,
                                contentDescription = "Senior Mode",
                                tint = if (isSenior) Color(0xFF3E2723) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (isSenior) "Senior: ON" else "Large Text",
                                fontSize = if (isSenior) 13.sp else 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSenior) Color(0xFF3E2723) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(Modifier.width(6.dp))

                    // Emergency Doctor Hotline Button
                    IconButton(
                        onClick = { showEmergencyDialog = true },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("emergency_doctor_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneInTalk,
                            contentDescription = "Emergency Doctor",
                            tint = SugarLowAlertRed,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            // ONE-HANDED DOCKED QUICK ACTION BAR
            // Positioned at the bottom for thumb reachability
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("one_handed_quick_action_bar"),
                tonalElevation = 8.dp,
                shadowElevation = 12.dp,
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "⚡ Quick Actions (One-Handed)",
                        fontSize = if (isSenior) 13.sp else 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Quick Add Sugar button
                        Button(
                            onClick = {
                                selectedSugarSlot = "Fasting"
                                showAddSugarDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(if (isSenior) 60.dp else 54.dp)
                                .testTag("btn_quick_add_sugar"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MedicalBluePrimary,
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WaterDrop,
                                contentDescription = null,
                                modifier = Modifier.size(if (isSenior) 26.dp else 22.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Add Sugar",
                                fontSize = if (isSenior) 17.sp else 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // 2. Mark Medicine Taken button
                        Button(
                            onClick = {
                                if (pendingMedicines.isEmpty()) {
                                    scope.launch {
                                        snackbarHostState.showSnackbar("All medicines are already taken today! 🎉")
                                    }
                                } else if (pendingMedicines.size == 1) {
                                    val med = pendingMedicines.first()
                                    viewModel.markMedicineTaken(med)
                                    scope.launch {
                                        val res = snackbarHostState.showSnackbar(
                                            message = "✓ ${med.name} marked as taken!",
                                            actionLabel = "Undo"
                                        )
                                        if (res == SnackbarResult.ActionPerformed) {
                                            viewModel.markMedicineTaken(med)
                                        }
                                    }
                                } else {
                                    showSelectMedDialog = true
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(if (isSenior) 60.dp else 54.dp)
                                .testTag("btn_mark_medicine_taken"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SugarNormalGreen,
                                contentColor = Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(if (isSenior) 26.dp else 22.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Mark Taken",
                                fontSize = if (isSenior) 17.sp else 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
        ) {
            // Patient Greeting & Target Range Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Hello, ${profile?.name ?: "Sarah"}",
                                fontSize = if (isSenior) 26.sp else 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "${profile?.diabetesType ?: "Type 2 Diabetes"} • Target: 70 - 140 mg/dL",
                                fontSize = if (isSenior) 15.sp else 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = SugarLowAlertRed,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 1. CURRENT BLOOD SUGAR CARD (Large Card & Large Typography)
            item {
                ElderlyCurrentSugarCard(
                    latestSugar = latestSugar,
                    isSenior = isSenior,
                    onLogNewClick = {
                        selectedSugarSlot = "Fasting"
                        showAddSugarDialog = true
                    },
                    onViewHistoryClick = onNavigateToSugarLogs
                )
            }

            // 2. NEXT MEDICINE REMINDER CARD (Large Card & Direct Action)
            item {
                ElderlyNextMedicineReminderCard(
                    nextMedicine = nextMedicine,
                    isPending = nextMedicine?.takenToday == false,
                    isSenior = isSenior,
                    onMarkTaken = { med ->
                        viewModel.markMedicineTaken(med, isLate = false)
                        scope.launch {
                            snackbarHostState.showSnackbar("✓ ${med.name} marked as taken on-time! (100% score)")
                        }
                    },
                    onMarkLate = { med ->
                        viewModel.markMedicineLate(med)
                        scope.launch {
                            snackbarHostState.showSnackbar("⏰ ${med.name} marked as taken late (50% score credit)")
                        }
                    },
                    onViewAllClick = onNavigateToMedicines
                )
            }

            // 3. MEDICINES DUE TODAY CARD (Large Schedule & Status)
            item {
                ElderlyMedicinesDueTodayCard(
                    medicines = medicines,
                    isSenior = isSenior,
                    onMarkTaken = { med -> viewModel.markMedicineTaken(med, isLate = false) },
                    onMarkLate = { med -> viewModel.markMedicineLate(med) },
                    onMarkMissed = { med -> viewModel.markMedicineMissed(med) },
                    onViewAllClick = onNavigateToMedicines
                )
            }

            // 4. ADHERENCE SCORE CARD (Daily, Weekly, Monthly with Trends)
            item {
                ElderlyAdherenceScoreCard(
                    viewModel = viewModel,
                    medicines = medicines,
                    doseLogs = doseLogs,
                    isSenior = isSenior
                )
            }

            // 5. LOW STOCK MEDICINES (High Visibility Alert Card)
            item {
                ElderlyLowStockMedicinesCard(
                    lowStockMeds = lowStockMeds,
                    isSenior = isSenior,
                    onRefill = { med ->
                        viewModel.refillMedicine(med, 30)
                        scope.launch {
                            snackbarHostState.showSnackbar("Refilled 30 doses of ${med.name}!")
                        }
                    }
                )
            }

            // Daily Hydration Card (Supportive for Seniors)
            item {
                ElderlyWaterIntakeCard(
                    glasses = waterGlasses,
                    isSenior = isSenior,
                    onAdd = { viewModel.incrementWater() },
                    onRemove = { viewModel.decrementWater() }
                )
            }

            // Daily Steps & Activity Card (Walking is vital for glucose control)
            item {
                ElderlyDailyActivityCard(
                    steps = dailySteps,
                    targetSteps = 6000,
                    isSenior = isSenior,
                    onAddSteps = { viewModel.addSteps(500) }
                )
            }

            // Respectful AdMob Banner
            item {
                AdMobBannerSimulation(isPremium = isPremium)
            }
        }
    }

    // ELDERLY-OPTIMIZED QUICK ADD SUGAR DIALOG
    if (showAddSugarDialog) {
        ElderlyAddSugarDialog(
            initialSlot = selectedSugarSlot,
            isSenior = isSenior,
            onDismiss = { showAddSugarDialog = false },
            onSave = { value, slot, notes ->
                viewModel.addSugarReading(value, slot, notes)
                showAddSugarDialog = false
                scope.launch {
                    snackbarHostState.showSnackbar("Recorded: $value mg/dL ($slot)")
                }
            }
        )
    }

    // SELECT MEDICINE TO MARK TAKEN DIALOG (When multiple pending)
    if (showSelectMedDialog) {
        SelectMedicineToTakeDialog(
            pendingMedicines = pendingMedicines,
            isSenior = isSenior,
            onDismiss = { showSelectMedDialog = false },
            onSelect = { med, isLate ->
                viewModel.markMedicineTaken(med, isLate = isLate)
                showSelectMedDialog = false
                scope.launch {
                    snackbarHostState.showSnackbar(
                        if (isLate) "⏰ ${med.name} marked as taken late (50% adherence)"
                        else "✓ ${med.name} marked as taken on-time! (100% adherence)"
                    )
                }
            }
        )
    }

    // EMERGENCY DOCTOR HOTLINE DIALOG
    if (showEmergencyDialog) {
        EmergencyCallDialog(
            doctorName = profile?.doctorName ?: "Dr. Michael Chen",
            doctorPhone = profile?.doctorPhone ?: "+15558765432",
            emergencyName = profile?.emergencyContactName ?: "David Jenkins",
            emergencyPhone = profile?.emergencyContactPhone ?: "+15552348901",
            onDismiss = { showEmergencyDialog = false }
        )
    }
}

// -------------------------------------------------------------
// 1. CURRENT BLOOD SUGAR CARD
// -------------------------------------------------------------
@Composable
fun ElderlyCurrentSugarCard(
    latestSugar: SugarLogEntity?,
    isSenior: Boolean,
    onLogNewClick: () -> Unit,
    onViewHistoryClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_current_blood_sugar"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bloodtype,
                            contentDescription = null,
                            tint = MedicalBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Current Blood Sugar",
                        fontSize = if (isSenior) 22.sp else 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(
                    onClick = onViewHistoryClick,
                    modifier = Modifier.testTag("btn_view_sugar_history")
                ) {
                    Text(
                        text = "History →",
                        fontSize = if (isSenior) 15.sp else 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            if (latestSugar != null) {
                val value = latestSugar.value
                val mmolValue = String.format(java.util.Locale.US, "%.1f", value / 18.0182)

                // Giant Readable Number
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${value.toInt()}",
                            fontSize = if (isSenior) 54.sp else 46.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = when {
                                value < 70 -> SugarLowAlertRed
                                value <= 140 -> SugarNormalGreen
                                else -> SugarHighAlertOrange
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.padding(bottom = 6.dp)) {
                            Text(
                                text = "mg/dL",
                                fontSize = if (isSenior) 20.sp else 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "($mmolValue mmol/L)",
                                fontSize = if (isSenior) 14.sp else 12.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    // Status Badge (Large)
                    GlucoseStatusBadgeLarge(value = value, isSenior = isSenior)
                }

                Spacer(Modifier.height(12.dp))

                // Timestamp & Meal Reading Context
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "${latestSugar.readingType} • ${latestSugar.time}",
                                fontSize = if (isSenior) 15.sp else 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Text(
                            text = latestSugar.date,
                            fontSize = if (isSenior) 14.sp else 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Target Range Indicator Bar
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Low (<70)",
                            fontSize = 11.sp,
                            color = SugarLowAlertRed,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Target (70-140 mg/dL)",
                            fontSize = 11.sp,
                            color = SugarNormalGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "High (>140)",
                            fontSize = 11.sp,
                            color = SugarHighAlertOrange,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(Modifier.height(6.dp))

                    // 3-colored target bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(70f)
                                .fillMaxHeight()
                                .background(SugarLowAlertRed.copy(alpha = 0.6f))
                        )
                        Box(
                            modifier = Modifier
                                .weight(70f)
                                .fillMaxHeight()
                                .background(SugarNormalGreen)
                        )
                        Box(
                            modifier = Modifier
                                .weight(100f)
                                .fillMaxHeight()
                                .background(SugarHighAlertOrange.copy(alpha = 0.6f))
                        )
                    }
                }
            } else {
                Text(
                    text = "No blood sugar recorded today yet.",
                    fontSize = if (isSenior) 16.sp else 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))

            // Large One-Handed Action Button inside Card
            OutlinedButton(
                onClick = onLogNewClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isSenior) 52.dp else 46.dp)
                    .testTag("btn_card_log_sugar"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MedicalBluePrimary
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Log New Sugar Reading",
                    fontSize = if (isSenior) 16.sp else 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// -------------------------------------------------------------
// 2. NEXT MEDICINE REMINDER CARD
// -------------------------------------------------------------
@Composable
fun ElderlyNextMedicineReminderCard(
    nextMedicine: MedicineEntity?,
    isPending: Boolean,
    isSenior: Boolean,
    onMarkTaken: (MedicineEntity) -> Unit,
    onMarkLate: (MedicineEntity) -> Unit,
    onViewAllClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_next_medicine_reminder"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (nextMedicine != null && isPending) {
                MaterialTheme.colorScheme.surface
            } else {
                Color(0xFFF0FDF4) // Gentle success green
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isPending) Color(0xFFEFF6FF) else Color(0xFFDCFCE7)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPending) Icons.Default.AccessAlarm else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isPending) MedicalBluePrimary else SugarNormalGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Next Medicine Reminder",
                        fontSize = if (isSenior) 22.sp else 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isPending) Color(0xFFDBEAFE) else Color(0xFFDCFCE7)
                ) {
                    Text(
                        text = if (isPending) "DUE SOON" else "ALL TAKEN ✓",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isPending) MedicalBluePrimary else SugarNormalGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            if (nextMedicine != null && isPending) {
                // Medicine Name in Large Typography
                Text(
                    text = nextMedicine.name,
                    fontSize = if (isSenior) 26.sp else 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(4.dp))

                // Dosage & Scheduled Time in large clear font
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${nextMedicine.dosage} • ${nextMedicine.category}",
                        fontSize = if (isSenior) 17.sp else 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MedicalBluePrimary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "⏰ ${nextMedicine.reminderTime}",
                        fontSize = if (isSenior) 17.sp else 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (nextMedicine.notes.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Instruction: ${nextMedicine.notes}",
                        fontSize = if (isSenior) 15.sp else 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(16.dp))

                // Large One-Handed Action Buttons on Card (On-Time vs Late)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onMarkTaken(nextMedicine) },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(if (isSenior) 56.dp else 48.dp)
                            .testTag("btn_next_med_mark_taken"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SugarNormalGreen,
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "On-Time ✓",
                            fontSize = if (isSenior) 18.sp else 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = { onMarkLate(nextMedicine) },
                        modifier = Modifier
                            .weight(1f)
                            .height(if (isSenior) 56.dp else 48.dp)
                            .testTag("btn_next_med_mark_late"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = SugarHighAlertOrange
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = null,
                            tint = SugarHighAlertOrange,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Late ⏰",
                            fontSize = if (isSenior) 16.sp else 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SugarHighAlertOrange
                        )
                    }
                }
            } else {
                // All medicines taken today
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🎉 All Medicines Taken Today!",
                        fontSize = if (isSenior) 20.sp else 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = SugarNormalGreen
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Great job sticking to your schedule. Next dose tomorrow morning.",
                        fontSize = if (isSenior) 15.sp else 13.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. MEDICINES DUE TODAY CARD
// -------------------------------------------------------------
@Composable
fun ElderlyMedicinesDueTodayCard(
    medicines: List<MedicineEntity>,
    isSenior: Boolean,
    onMarkTaken: (MedicineEntity) -> Unit,
    onMarkLate: (MedicineEntity) -> Unit,
    onMarkMissed: (MedicineEntity) -> Unit,
    onViewAllClick: () -> Unit
) {
    val takenCount = medicines.count { it.takenToday }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_medicines_due_today"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Medication,
                            contentDescription = null,
                            tint = MedicalBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Medicines Due Today",
                        fontSize = if (isSenior) 22.sp else 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(onClick = onViewAllClick) {
                    Text(
                        text = "Manage (${medicines.size})",
                        fontSize = if (isSenior) 15.sp else 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Progress Summary: "2 of 3 doses taken"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$takenCount of ${medicines.size} doses completed",
                    fontSize = if (isSenior) 16.sp else 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (medicines.isNotEmpty()) "${(takenCount * 100) / medicines.size}%" else "100%",
                    fontSize = if (isSenior) 16.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SugarNormalGreen
                )
            }

            Spacer(Modifier.height(6.dp))

            val progress = if (medicines.isNotEmpty()) takenCount.toFloat() / medicines.size else 1f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = SugarNormalGreen,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(Modifier.height(16.dp))

            if (medicines.isEmpty()) {
                Text(
                    text = "No medicines configured. Tap Manage to add medications.",
                    fontSize = if (isSenior) 15.sp else 13.sp,
                    color = Color.Gray
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    medicines.forEach { med ->
                        ElderlyMedicineRowItem(
                            medicine = med,
                            isSenior = isSenior,
                            onTakenClick = { onMarkTaken(med) },
                            onLateClick = { onMarkLate(med) },
                            onMissedClick = { onMarkMissed(med) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ElderlyMedicineRowItem(
    medicine: MedicineEntity,
    isSenior: Boolean,
    onTakenClick: () -> Unit,
    onLateClick: () -> Unit,
    onMissedClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = when {
            medicine.takenToday && !medicine.lateToday -> Color(0xFFF0FDF4)
            medicine.lateToday -> Color(0xFFFEF3C7)
            medicine.missedToday -> Color(0xFFFEF2F2)
            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        },
        border = when {
            medicine.takenToday && !medicine.lateToday -> androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0))
            medicine.lateToday -> androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A))
            else -> null
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Category Icon & Details
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = when {
                        medicine.takenToday && !medicine.lateToday -> SugarNormalGreen
                        medicine.lateToday -> SugarHighAlertOrange
                        else -> MedicalBluePrimary
                    },
                    modifier = Modifier.size(if (isSenior) 44.dp else 38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when (medicine.category) {
                                "Insulin" -> Icons.Default.Vaccines
                                "Syrup" -> Icons.Default.LocalDrink
                                else -> Icons.Default.Medication
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(if (isSenior) 24.dp else 20.dp)
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column {
                    Text(
                        text = medicine.name,
                        fontSize = if (isSenior) 19.sp else 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${medicine.dosage} • ⏰ ${medicine.reminderTime}",
                        fontSize = if (isSenior) 15.sp else 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.width(8.dp))

            // Action: Mark Taken / Taken Badge
            if (medicine.takenToday) {
                Button(
                    onClick = onTakenClick, // Clicking again allows undo
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (medicine.lateToday) Color(0xFFFEF3C7) else SugarNormalGreenBg,
                        contentColor = if (medicine.lateToday) SugarHighAlertOrange else SugarNormalGreen
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.height(if (isSenior) 48.dp else 40.dp)
                ) {
                    Icon(
                        imageVector = if (medicine.lateToday) Icons.Default.AccessTime else Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (medicine.lateToday) "Late ⏰" else "Taken ✓",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 15.sp else 13.sp
                    )
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onTakenClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MedicalBluePrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(if (isSenior) 48.dp else 40.dp)
                            .testTag("btn_take_${medicine.name}")
                    ) {
                        Text(
                            text = "Take",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 15.sp else 13.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onLateClick,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier.height(if (isSenior) 48.dp else 40.dp)
                    ) {
                        Text(
                            text = "Late",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 13.sp else 11.sp,
                            color = SugarHighAlertOrange
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. ADHERENCE SCORE CARD (Daily, Weekly, Monthly with Trends)
// -------------------------------------------------------------
@Composable
fun ElderlyAdherenceScoreCard(
    viewModel: SugarTrackViewModel,
    medicines: List<MedicineEntity>,
    doseLogs: List<DoseLogEntity>,
    isSenior: Boolean
) {
    var selectedPeriod by remember { mutableStateOf("Weekly") } // "Daily", "Weekly", "Monthly"
    val summary = remember(selectedPeriod, medicines, doseLogs) {
        viewModel.getAdherenceSummary(selectedPeriod, medicines, doseLogs)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_adherence_score"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                when (summary.grade) {
                                    AdherenceGrade.EXCELLENT -> Color(0xFFDCFCE7)
                                    AdherenceGrade.GOOD -> Color(0xFFDBEAFE)
                                    AdherenceGrade.FAIR -> Color(0xFFFEF3C7)
                                    AdherenceGrade.POOR -> Color(0xFFFEE2E2)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircleOutline,
                            contentDescription = null,
                            tint = when (summary.grade) {
                                AdherenceGrade.EXCELLENT -> SugarNormalGreen
                                AdherenceGrade.GOOD -> MedicalBluePrimary
                                AdherenceGrade.FAIR -> SugarHighAlertOrange
                                AdherenceGrade.POOR -> SugarLowAlertRed
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Adherence Score",
                        fontSize = if (isSenior) 22.sp else 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Grade Badge (e.g. Excellent 90-100%, Good 75-89%, etc.)
                AdherenceGradeBadge(grade = summary.grade, isSenior = isSenior)
            }

            Spacer(Modifier.height(14.dp))

            // Time Period Selector: [ Daily Score ] [ Weekly Score ] [ Monthly Score ]
            val periods = listOf(
                Pair("Daily", "Daily Score"),
                Pair("Weekly", "Weekly Score"),
                Pair("Monthly", "Monthly Score")
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                periods.forEach { (key, displayTitle) ->
                    val isSelected = selectedPeriod.equals(key, ignoreCase = true)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                        shadowElevation = if (isSelected) 2.dp else 0.dp,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPeriod = key }
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(vertical = if (isSenior) 10.dp else 8.dp)
                        ) {
                            Text(
                                text = displayTitle,
                                fontSize = if (isSenior) 14.sp else 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MedicalBluePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // 4 Adherence Standard Tiers Display
            AdherenceTiersDisplay(isSenior = isSenior)

            Spacer(Modifier.height(14.dp))

            // Score and Breakdown display
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "${summary.score}%",
                        fontSize = if (isSenior) 54.sp else 46.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = when (summary.grade) {
                            AdherenceGrade.EXCELLENT -> SugarNormalGreen
                            AdherenceGrade.GOOD -> MedicalBluePrimary
                            AdherenceGrade.FAIR -> SugarHighAlertOrange
                            AdherenceGrade.POOR -> SugarLowAlertRed
                        }
                    )
                    Text(
                        text = "$selectedPeriod Score • ${summary.grade.label}",
                        fontSize = if (isSenior) 16.sp else 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Breakdown Chips (Taken, Late, Missed)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFDCFCE7)
                    ) {
                        Text(
                            text = "✓ On-Time: ${summary.takenOnTimeCount}",
                            fontSize = if (isSenior) 14.sp else 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SugarNormalGreen,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFEF3C7)
                    ) {
                        Text(
                            text = "⏰ Late: ${summary.lateCount}",
                            fontSize = if (isSenior) 14.sp else 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SugarHighAlertOrange,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (summary.missedCount > 0) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "✕ Missed: ${summary.missedCount}",
                            fontSize = if (isSenior) 14.sp else 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (summary.missedCount > 0) SugarLowAlertRed else Color.Gray,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Clinical Explanation
            Text(
                text = summary.grade.description,
                fontSize = if (isSenior) 15.sp else 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = if (isSenior) 22.sp else 18.sp
            )

            Spacer(Modifier.height(14.dp))

            // Charts and Trends Component
            AdherenceTrendChart(
                points = summary.trendPoints,
                heightDp = if (isSenior) 170 else 145,
                isSenior = isSenior
            )
        }
    }
}


// -------------------------------------------------------------
// 5. LOW STOCK MEDICINES CARD
// -------------------------------------------------------------
@Composable
fun ElderlyLowStockMedicinesCard(
    lowStockMeds: List<MedicineEntity>,
    isSenior: Boolean,
    onRefill: (MedicineEntity) -> Unit
) {
    if (lowStockMeds.isNotEmpty()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("card_low_stock_medicines"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFCA5A5)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEE2E2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = SugarLowAlertRed,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Low Stock Medicine Alert",
                            fontSize = if (isSenior) 22.sp else 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF991B1B)
                        )
                        Text(
                            text = "${lowStockMeds.size} medication(s) need refilling soon",
                            fontSize = if (isSenior) 15.sp else 13.sp,
                            color = Color(0xFFB91C1C)
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    lowStockMeds.forEach { med ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = med.name,
                                        fontSize = if (isSenior) 18.sp else 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Only ${med.quantityAvailable} doses left in bottle!",
                                        fontSize = if (isSenior) 14.sp else 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = SugarLowAlertRed
                                    )
                                }

                                Button(
                                    onClick = { onRefill(med) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFDC2626),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(if (isSenior) 48.dp else 40.dp)
                                ) {
                                    Text(
                                        text = "Refill 30",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (isSenior) 15.sp else 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Healthy stock reassuring card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCFCE7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = SugarNormalGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Medicine Stocks are Healthy",
                        fontSize = if (isSenior) 18.sp else 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "All prescriptions have plenty of supply (10+ days)",
                        fontSize = if (isSenior) 14.sp else 12.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SUPPORTIVE ELDERLY HEALTH CARDS
// -------------------------------------------------------------
@Composable
fun ElderlyWaterIntakeCard(
    glasses: Int,
    isSenior: Boolean,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalDrink, contentDescription = null, tint = Color(0xFF0288D1), modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Hydration & Water",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 20.sp else 16.sp
                    )
                }
                Text(
                    text = "$glasses of 8 Glasses",
                    fontSize = if (isSenior) 16.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0288D1)
                )
            }

            Spacer(Modifier.height(10.dp))

            val progress = (glasses / 8f).coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = Color(0xFF0288D1),
                trackColor = Color(0xFFE1F5FE)
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (glasses >= 8) "Daily target reached! 🎉" else "Drinking water supports kidney health",
                    fontSize = if (isSenior) 14.sp else 12.sp,
                    color = Color.Gray
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedIconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(44.dp),
                        enabled = glasses > 0
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(20.dp))
                    }
                    IconButton(
                        onClick = onAdd,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0288D1))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Glass", tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ElderlyDailyActivityCard(
    steps: Int,
    targetSteps: Int,
    isSenior: Boolean,
    onAddSteps: () -> Unit
) {
    val progress = (steps.toFloat() / targetSteps).coerceIn(0f, 1f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = MedicalBlueLight, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Daily Walking Activity",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 20.sp else 16.sp
                    )
                }

                OutlinedButton(
                    onClick = onAddSteps,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("+500 Steps", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = String.format(java.util.Locale.US, "%,d steps", steps),
                    fontSize = if (isSenior) 28.sp else 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MedicalBluePrimary
                )
                Text(
                    text = "Goal: ${String.format(java.util.Locale.US, "%,d", targetSteps)}",
                    fontSize = if (isSenior) 15.sp else 13.sp,
                    color = Color.Gray
                )
            }

            Spacer(Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = MedicalBluePrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

// -------------------------------------------------------------
// ELDERLY-FRIENDLY DIALOGS
// -------------------------------------------------------------
@Composable
fun GlucoseStatusBadgeLarge(value: Double, isSenior: Boolean) {
    val (status, bg, fg) = when {
        value < 70 -> Triple("Low (Hypo)", Color(0xFFFEE2E2), SugarLowAlertRed)
        value <= 140 -> Triple("In Target ✓", Color(0xFFDCFCE7), SugarNormalGreen)
        value <= 180 -> Triple("Elevated", Color(0xFFFEF3C7), SugarHighAlertOrange)
        else -> Triple("High (Hyper)", Color(0xFFFFEBEE), SugarVeryHighAlertRed)
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bg
    ) {
        Text(
            text = status,
            color = fg,
            fontWeight = FontWeight.ExtraBold,
            fontSize = if (isSenior) 15.sp else 13.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ElderlyAddSugarDialog(
    initialSlot: String,
    isSenior: Boolean,
    onDismiss: () -> Unit,
    onSave: (value: Double, slot: String, notes: String) -> Unit
) {
    var currentValue by remember { mutableIntStateOf(115) }
    var selectedSlot by remember { mutableStateOf(initialSlot) }
    var notes by remember { mutableStateOf("") }

    val commonSlots = listOf(
        "Fasting",
        "Post Breakfast",
        "Pre Lunch",
        "Post Lunch",
        "Bedtime",
        "Random"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WaterDrop, contentDescription = null, tint = MedicalBluePrimary, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "Quick Add Blood Sugar",
                    fontWeight = FontWeight.Bold,
                    fontSize = if (isSenior) 22.sp else 19.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Giant Value Display with +/- Stepper for One-Handed Adjustment
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$currentValue",
                            fontSize = 56.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = when {
                                currentValue < 70 -> SugarLowAlertRed
                                currentValue <= 140 -> SugarNormalGreen
                                else -> SugarHighAlertOrange
                            }
                        )
                        Text(
                            text = "mg/dL (${String.format(java.util.Locale.US, "%.1f", currentValue / 18.0182)} mmol/L)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Gray
                        )

                        Spacer(Modifier.height(12.dp))

                        // Large Thumb Stepper Buttons
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = { currentValue = (currentValue - 5).coerceAtLeast(40) },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text("- 5", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Button(
                                onClick = { currentValue = (currentValue - 1).coerceAtLeast(40) },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text("- 1", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Button(
                                onClick = { currentValue = (currentValue + 1).coerceAtMost(500) },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text("+ 1", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Button(
                                onClick = { currentValue = (currentValue + 5).coerceAtMost(500) },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text("+ 5", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                // Meal Slot Selector with Large Chips
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "When was this measured?",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(commonSlots) { slot ->
                            FilterChip(
                                selected = selectedSlot == slot,
                                onClick = { selectedSlot = slot },
                                label = {
                                    Text(
                                        text = slot,
                                        fontSize = if (isSenior) 14.sp else 12.sp,
                                        fontWeight = if (selectedSlot == slot) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(42.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(currentValue.toDouble(), selectedSlot, notes) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_save_sugar_reading"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary)
            ) {
                Text("Save Reading", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cancel", fontSize = 15.sp)
            }
        }
    )
}

@Composable
fun SelectMedicineToTakeDialog(
    pendingMedicines: List<MedicineEntity>,
    isSenior: Boolean,
    onDismiss: () -> Unit,
    onSelect: (MedicineEntity, isLate: Boolean) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Medication, contentDescription = null, tint = SugarNormalGreen, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "Select Medicine Taken",
                    fontWeight = FontWeight.Bold,
                    fontSize = if (isSenior) 22.sp else 19.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Select medicine and dose timing:",
                    fontSize = if (isSenior) 15.sp else 13.sp,
                    color = Color.Gray
                )

                pendingMedicines.forEach { med ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Text(
                                text = med.name,
                                fontSize = if (isSenior) 18.sp else 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${med.dosage} • ⏰ ${med.reminderTime}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )

                            Spacer(Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onSelect(med, false) },
                                    modifier = Modifier.weight(1.2f).height(44.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SugarNormalGreen,
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("On-Time ✓", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { onSelect(med, true) },
                                    modifier = Modifier.weight(1f).height(44.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = SugarHighAlertOrange
                                    )
                                ) {
                                    Text("Late ⏰", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SugarHighAlertOrange)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                Text("Close", fontSize = 15.sp)
            }
        }
    )
}


@Composable
fun AddSugarLogDialog(
    initialType: String = "Fasting",
    onDismiss: () -> Unit,
    onSave: (value: Double, type: String, notes: String) -> Unit,
    isSenior: Boolean = false
) {
    ElderlyAddSugarDialog(
        initialSlot = initialType,
        isSenior = isSenior,
        onDismiss = onDismiss,
        onSave = onSave
    )
}
