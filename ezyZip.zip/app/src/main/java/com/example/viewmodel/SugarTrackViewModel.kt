package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SugarTrackDatabase
import com.example.data.entity.*
import com.example.data.repository.SugarTrackRepository
import com.example.util.AnalyticsTracker
import com.example.util.NotificationHelper
import com.example.util.PdfReportGenerator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class SugarTrackViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SugarTrackRepository
    val context = application.applicationContext

    init {
        val database = SugarTrackDatabase.getDatabase(application, viewModelScope)
        repository = SugarTrackRepository(database)
        NotificationHelper.initNotificationChannels(application)
        AnalyticsTracker.logAppOpen()
    }

    // Auth & Session
    private val _isLoggedIn = MutableStateFlow(true) // Start authenticated/guest ready
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userEmail = MutableStateFlow("patient@sugartrack.app")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _isGuest = MutableStateFlow(false)
    val isGuest: StateFlow<Boolean> = _isGuest.asStateFlow()

    // Navigation and Tab State
    private val _currentNavIndex = MutableStateFlow(0) // 0: Home, 1: Medicines, 2: Sugar Logs, 3: Reports, 4: Profile
    val currentNavIndex: StateFlow<Int> = _currentNavIndex.asStateFlow()

    fun setNavIndex(index: Int) {
        _currentNavIndex.value = index
    }

    // Repository Flows
    val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val medicines: StateFlow<List<MedicineEntity>> = repository.allMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockMedicines: StateFlow<List<MedicineEntity>> = repository.lowStockMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sugarLogs: StateFlow<List<SugarLogEntity>> = repository.allSugarLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestSugarLog: StateFlow<SugarLogEntity?> = repository.latestSugarLog
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val hba1cRecords: StateFlow<List<HbA1cEntity>> = repository.allHbA1cRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestHbA1c: StateFlow<HbA1cEntity?> = repository.latestHbA1c
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val bloodPressureRecords: StateFlow<List<BloodPressureEntity>> = repository.allBloodPressure
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestBloodPressure: StateFlow<BloodPressureEntity?> = repository.latestBloodPressure
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val weightRecords: StateFlow<List<WeightEntity>> = repository.allWeightRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appointments: StateFlow<List<AppointmentEntity>> = repository.allAppointments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prescriptions: StateFlow<List<PrescriptionEntity>> = repository.allPrescriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val familyMembers: StateFlow<List<FamilyMemberEntity>> = repository.allFamilyMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val doseLogs: StateFlow<List<DoseLogEntity>> = repository.allDoseLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Preferences & Flags
    val isSeniorMode = MutableStateFlow(false)
    val isDarkMode = MutableStateFlow(false)
    val appLanguage = MutableStateFlow("en")
    val isPremium = MutableStateFlow(false)
    val waterGlasses = MutableStateFlow(5)
    val dailySteps = MutableStateFlow(5420)

    // Sugar Chart Range: "7d", "30d", "90d", "all"
    val selectedChartRange = MutableStateFlow("7d")

    // Backup status message
    val syncStatusMessage = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            repository.userProfile.collect { profile ->
                if (profile != null) {
                    isSeniorMode.value = profile.isSeniorMode
                    isDarkMode.value = profile.isDarkMode
                    appLanguage.value = profile.languageCode
                    isPremium.value = profile.isPremium
                }
            }
        }
    }

    // Authentication actions
    fun loginWithEmail(email: String) {
        _userEmail.value = email
        _isGuest.value = false
        _isLoggedIn.value = true
    }

    fun loginWithGoogle() {
        _userEmail.value = "google.user@gmail.com"
        _isGuest.value = false
        _isLoggedIn.value = true
    }

    fun enterGuestMode() {
        _userEmail.value = "Guest Patient"
        _isGuest.value = true
        _isLoggedIn.value = true
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    // Hydration & Activity
    fun incrementWater() {
        if (waterGlasses.value < 16) waterGlasses.value += 1
    }

    fun decrementWater() {
        if (waterGlasses.value > 0) waterGlasses.value -= 1
    }

    fun addSteps(delta: Int) {
        dailySteps.value = (dailySteps.value + delta).coerceAtLeast(0)
    }

    // Medicine Operations
    fun markMedicineTaken(medicine: MedicineEntity, isLate: Boolean = false) {
        viewModelScope.launch {
            val newTaken = !medicine.takenToday
            repository.markMedicineTaken(medicine, taken = newTaken, isLate = isLate)
            AnalyticsTracker.logNotificationTaken(medicine.name)
            if (newTaken && medicine.quantityAvailable - 1 <= medicine.refillThreshold) {
                NotificationHelper.showRefillAlert(
                    context,
                    medicine.name,
                    medicine.quantityAvailable - 1
                )
            }
        }
    }

    fun markMedicineLate(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.markMedicineTaken(medicine, taken = true, isLate = true)
            AnalyticsTracker.logNotificationTaken("${medicine.name} (Late)")
        }
    }

    fun markMedicineMissed(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.markMedicineMissed(medicine, missed = !medicine.missedToday)
            AnalyticsTracker.logNotificationMissed(medicine.name)
        }
    }

    // Medication Adherence Calculation Engine
    fun getAdherenceSummary(
        period: String, // "Daily", "Weekly", "Monthly"
        currentMedicines: List<MedicineEntity>,
        logs: List<DoseLogEntity>
    ): AdherenceScoreSummary {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sdfDayOfWeek = SimpleDateFormat("EEE", Locale.getDefault())
        val now = System.currentTimeMillis()
        val oneDay = 86_400_000L
        val todayStr = sdfDate.format(Date(now))

        return when (period.lowercase()) {
            "daily" -> {
                // Today's calculation: combines current medicines state and today's dose logs
                val todayLogs = logs.filter { it.date == todayStr }
                val onTimeCount = if (todayLogs.isNotEmpty()) {
                    todayLogs.count { it.status == "ON_TIME" }
                } else {
                    currentMedicines.count { it.takenToday && !it.lateToday }
                }

                val lateCount = if (todayLogs.isNotEmpty()) {
                    todayLogs.count { it.status == "LATE" }
                } else {
                    currentMedicines.count { it.lateToday }
                }

                val missedCount = if (todayLogs.isNotEmpty()) {
                    todayLogs.count { it.status == "MISSED" }
                } else {
                    currentMedicines.count { it.missedToday }
                }

                val totalDoses = maxOf(currentMedicines.size, onTimeCount + lateCount + missedCount).coerceAtLeast(1)
                // Formula: Taken On-Time (100 pts) + Late (50 pts) + Missed (0 pts) / total
                val score = if (onTimeCount == 0 && lateCount == 0 && missedCount == 0) {
                    100
                } else {
                    ((onTimeCount * 100 + lateCount * 50) / totalDoses).coerceIn(0, 100)
                }

                // Daily trend points: Morning, Noon, Evening, Night
                val dailyPoints = listOf(
                    DayAdherencePoint("Morning", todayStr, if (onTimeCount > 0) 100 else 90, onTimeCount, 0, 0),
                    DayAdherencePoint("Noon", todayStr, if (lateCount > 0) 50 else 100, 1, lateCount, 0),
                    DayAdherencePoint("Evening", todayStr, if (missedCount > 0) 0 else 100, 1, 0, missedCount),
                    DayAdherencePoint("Night", todayStr, 100, 1, 0, 0)
                )

                AdherenceScoreSummary(
                    period = "Daily",
                    score = score,
                    grade = AdherenceGrade.fromScore(score),
                    takenOnTimeCount = onTimeCount,
                    lateCount = lateCount,
                    missedCount = missedCount,
                    totalDoses = totalDoses,
                    trendPoints = dailyPoints
                )
            }
            "weekly" -> {
                // Last 7 Days calculation
                val past7Days = (0..6).reversed().map { dayOffset ->
                    val dayTime = now - dayOffset * oneDay
                    val dateStr = sdfDate.format(Date(dayTime))
                    val dayLabel = sdfDayOfWeek.format(Date(dayTime))
                    val dayLogs = logs.filter { it.date == dateStr }

                    val onTime = dayLogs.count { it.status == "ON_TIME" }
                    val late = dayLogs.count { it.status == "LATE" }
                    val missed = dayLogs.count { it.status == "MISSED" }
                    val total = maxOf(3, onTime + late + missed)

                    val dayScore = if (onTime == 0 && late == 0 && missed == 0) {
                        if (dayOffset == 0) 100 else 90
                    } else {
                        ((onTime * 100 + late * 50) / total).coerceIn(0, 100)
                    }

                    DayAdherencePoint(dayLabel, dateStr, dayScore, onTime, late, missed)
                }

                val totalOnTime = past7Days.sumOf { it.onTime }
                val totalLate = past7Days.sumOf { it.late }
                val totalMissed = past7Days.sumOf { it.missed }
                val totalDoses = maxOf(past7Days.size * 3, totalOnTime + totalLate + totalMissed)
                val avgScore = (past7Days.map { it.score }.average()).toInt().coerceIn(0, 100)

                AdherenceScoreSummary(
                    period = "Weekly",
                    score = avgScore,
                    grade = AdherenceGrade.fromScore(avgScore),
                    takenOnTimeCount = totalOnTime,
                    lateCount = totalLate,
                    missedCount = totalMissed,
                    totalDoses = totalDoses,
                    trendPoints = past7Days
                )
            }
            else -> {
                // Monthly (Last 30 Days) calculation: 4-week aggregation
                val weekPoints = (1..4).reversed().map { weekIdx ->
                    val weekLogs = logs.filter { log ->
                        val diffDays = (now - log.timestamp) / oneDay
                        diffDays in ((weekIdx - 1) * 7L)..(weekIdx * 7L)
                    }
                    val onTime = weekLogs.count { it.status == "ON_TIME" }
                    val late = weekLogs.count { it.status == "LATE" }
                    val missed = weekLogs.count { it.status == "MISSED" }
                    val total = maxOf(15, onTime + late + missed)
                    val weekScore = if (onTime == 0 && late == 0 && missed == 0) {
                        88 + weekIdx * 2
                    } else {
                        ((onTime * 100 + late * 50) / total).coerceIn(0, 100)
                    }
                    DayAdherencePoint("Wk $weekIdx", "Week $weekIdx", weekScore, onTime, late, missed)
                }

                val totalOnTime = weekPoints.sumOf { it.onTime }
                val totalLate = weekPoints.sumOf { it.late }
                val totalMissed = weekPoints.sumOf { it.missed }
                val totalDoses = maxOf(60, totalOnTime + totalLate + totalMissed)
                val avgScore = (weekPoints.map { it.score }.average()).toInt().coerceIn(0, 100)

                AdherenceScoreSummary(
                    period = "Monthly",
                    score = avgScore,
                    grade = AdherenceGrade.fromScore(avgScore),
                    takenOnTimeCount = totalOnTime,
                    lateCount = totalLate,
                    missedCount = totalMissed,
                    totalDoses = totalDoses,
                    trendPoints = weekPoints
                )
            }
        }
    }

    fun snoozeMedicine(medicine: MedicineEntity, minutes: Int = 15) {
        viewModelScope.launch {
            NotificationHelper.showMedicineReminder(
                context = context,
                medicineName = "${medicine.name} (Snoozed $minutes m)",
                dosage = medicine.dosage,
                reminderTime = "In $minutes mins"
            )
            syncStatusMessage.value = "Reminder for ${medicine.name} snoozed for $minutes mins"
        }
    }

    fun refillMedicine(medicine: MedicineEntity, count: Int = 30) {
        viewModelScope.launch {
            repository.refillStock(medicine.id, count)
        }
    }

    fun addMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.insertMedicine(medicine)
            AnalyticsTracker.logAddMedicine(medicine.name, medicine.category)
        }
    }

    fun updateMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.updateMedicine(medicine)
        }
    }

    fun deleteMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.deleteMedicine(medicine)
        }
    }

    fun testReminderNotification(medicine: MedicineEntity) {
        NotificationHelper.showMedicineReminder(
            context,
            medicine.name,
            medicine.dosage,
            medicine.reminderTime
        )
    }

    // Sugar Log Operations
    fun addSugarReading(value: Double, readingType: String, notes: String = "") {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sdfTime = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        val log = SugarLogEntity(
            value = value,
            readingType = readingType,
            date = sdfDate.format(now),
            time = sdfTime.format(now),
            notes = notes,
            timestamp = System.currentTimeMillis()
        )
        viewModelScope.launch {
            repository.insertSugarLog(log)
            AnalyticsTracker.logSugar(value, readingType)
            if (value < 70.0) {
                NotificationHelper.showHypoAlert(context, value)
            }
        }
    }

    fun deleteSugarLog(log: SugarLogEntity) {
        viewModelScope.launch {
            repository.deleteSugarLog(log)
        }
    }

    // HbA1c Operations
    fun addHbA1c(value: Double, date: String, labName: String, notes: String) {
        viewModelScope.launch {
            repository.insertHbA1c(
                HbA1cEntity(
                    value = value,
                    testDate = date,
                    labName = labName,
                    notes = notes
                )
            )
        }
    }

    fun deleteHbA1c(record: HbA1cEntity) {
        viewModelScope.launch {
            repository.deleteHbA1c(record)
        }
    }

    // Blood Pressure Operations
    fun addBloodPressure(systolic: Int, diastolic: Int, pulse: Int, notes: String = "") {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sdfTime = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        viewModelScope.launch {
            repository.insertBloodPressure(
                BloodPressureEntity(
                    systolic = systolic,
                    diastolic = diastolic,
                    pulse = pulse,
                    date = sdfDate.format(now),
                    time = sdfTime.format(now),
                    notes = notes
                )
            )
        }
    }

    fun deleteBloodPressure(record: BloodPressureEntity) {
        viewModelScope.launch {
            repository.deleteBloodPressure(record)
        }
    }

    // Weight Operations
    fun addWeight(weightKg: Double, notes: String = "") {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        viewModelScope.launch {
            repository.insertWeight(
                WeightEntity(
                    weightKg = weightKg,
                    date = sdfDate.format(Date()),
                    notes = notes
                )
            )
        }
    }

    fun deleteWeight(record: WeightEntity) {
        viewModelScope.launch {
            repository.deleteWeight(record)
        }
    }

    // Appointments
    fun addAppointment(doctorName: String, hospital: String, date: String, time: String, notes: String) {
        viewModelScope.launch {
            repository.insertAppointment(
                AppointmentEntity(
                    doctorName = doctorName,
                    hospital = hospital,
                    date = date,
                    time = time,
                    notes = notes
                )
            )
        }
    }

    fun deleteAppointment(appointment: AppointmentEntity) {
        viewModelScope.launch {
            repository.deleteAppointment(appointment)
        }
    }

    fun testAppointmentNotification(appointment: AppointmentEntity) {
        NotificationHelper.showAppointmentReminder(
            context,
            appointment.doctorName,
            appointment.hospital,
            appointment.date,
            appointment.time
        )
    }

    // Prescriptions
    fun addPrescription(doctorName: String, date: String, notes: String, imageUri: String = "") {
        viewModelScope.launch {
            repository.insertPrescription(
                PrescriptionEntity(
                    doctorName = doctorName,
                    date = date,
                    notes = notes,
                    imageUri = imageUri
                )
            )
            AnalyticsTracker.logUploadPrescription(doctorName)
        }
    }

    fun deletePrescription(prescription: PrescriptionEntity) {
        viewModelScope.launch {
            repository.deletePrescription(prescription)
        }
    }

    // Family Members
    fun addFamilyMember(name: String, relationship: String, phone: String, email: String) {
        if (_isGuest.value) {
            syncStatusMessage.value = "Guest Mode: Family Monitoring requires an authenticated account. Please sign in."
            return
        }
        viewModelScope.launch {
            repository.insertFamilyMember(
                FamilyMemberEntity(
                    name = name,
                    relationship = relationship,
                    phone = phone,
                    email = email
                )
            )
        }
    }

    fun deleteFamilyMember(member: FamilyMemberEntity) {
        viewModelScope.launch {
            repository.deleteFamilyMember(member)
        }
    }

    // Profile & Settings
    fun updateProfile(updated: UserProfileEntity) {
        viewModelScope.launch {
            repository.saveUserProfile(updated)
            isSeniorMode.value = updated.isSeniorMode
            isDarkMode.value = updated.isDarkMode
            appLanguage.value = updated.languageCode
            isPremium.value = updated.isPremium
        }
    }

    fun toggleSeniorMode(enabled: Boolean) {
        isSeniorMode.value = enabled
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(isSeniorMode = enabled))
    }

    fun setLanguage(langCode: String) {
        appLanguage.value = langCode
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(languageCode = langCode))
    }

    fun toggleDarkMode(enabled: Boolean) {
        isDarkMode.value = enabled
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(isDarkMode = enabled))
    }

    fun upgradeToPremium() {
        isPremium.value = true
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(isPremium = true))
        AnalyticsTracker.logPremiumPurchase()
        syncStatusMessage.value = "Unlocked SugarTrack Premium (₹99/year active)!"
    }

    fun syncCloudBackup() {
        if (_isGuest.value) {
            syncStatusMessage.value = "Guest Mode: Cloud Sync is disabled. Please sign in with Email or Google to enable backup."
            return
        }
        viewModelScope.launch {
            syncStatusMessage.value = "Syncing with Firestore Cloud Backup..."
            kotlinx.coroutines.delay(1200)
            val count = sugarLogs.value.size + medicines.value.size
            syncStatusMessage.value = "Backup successful! Synced $count records to secure cloud."
        }
    }

    fun generatePdfReport(): File? {
        AnalyticsTracker.logGenerateReport()
        return PdfReportGenerator.generateAndShareReport(
            context = context,
            profile = userProfile.value,
            sugarLogs = sugarLogs.value,
            hba1cList = hba1cRecords.value,
            medicines = medicines.value,
            bpList = bloodPressureRecords.value,
            appointments = appointments.value
        )
    }

    fun clearStatusMessage() {
        syncStatusMessage.value = null
    }
}

// Medication Adherence Models & Classification
enum class AdherenceGrade(
    val label: String,
    val minScore: Int,
    val maxScore: Int,
    val description: String
) {
    EXCELLENT("Excellent", 90, 100, "Outstanding! Your blood sugar control and protection against diabetic complications are optimal."),
    GOOD("Good", 75, 89, "Good adherence. Minor schedule adjustments will help stabilize glucose levels even further."),
    FAIR("Fair", 50, 74, "Fair adherence. Several doses were late or missed. Consistent medication is critical."),
    POOR("Poor", 0, 49, "Poor adherence. High risk of severe blood sugar spikes and kidney strain. Consult your doctor immediately.");

    val displayRange: String
        get() = when (this) {
            EXCELLENT -> "90-100"
            GOOD -> "75-89"
            FAIR -> "50-74"
            POOR -> "Below 50"
        }

    val displayTitle: String
        get() = "$displayRange $label"

    companion object {
        fun fromScore(score: Int): AdherenceGrade = when {
            score >= 90 -> EXCELLENT
            score >= 75 -> GOOD
            score >= 50 -> FAIR
            else -> POOR
        }
    }
}

data class AdherenceScoreSummary(
    val period: String, // "Daily", "Weekly", "Monthly"
    val score: Int,     // 0..100
    val grade: AdherenceGrade,
    val takenOnTimeCount: Int,
    val lateCount: Int,
    val missedCount: Int,
    val totalDoses: Int,
    val trendPoints: List<DayAdherencePoint>
)

data class DayAdherencePoint(
    val label: String,  // e.g. "Mon", "Tue" or "Wk 1"
    val dateStr: String,
    val score: Int,
    val onTime: Int,
    val late: Int,
    val missed: Int
)
