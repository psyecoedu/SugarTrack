package com.example

import com.example.viewmodel.AdherenceGrade
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testGlucoseConversionMmol() {
    val mgDl = 118.0
    val mmol = mgDl / 18.0182
    assertEquals("6.5", String.format(java.util.Locale.US, "%.1f", mmol))
  }

  @Test
  fun testAdherenceScoreCalculationFormula() {
    // 3 taken on-time, 1 late, 0 missed -> (3*100 + 1*50 + 0) / 4 = 350 / 4 = 87% (Good)
    val onTime = 3
    val late = 1
    val missed = 0
    val total = onTime + late + missed
    val score = ((onTime * 100 + late * 50 + missed * 0) / total).coerceIn(0, 100)
    assertEquals(87, score)
    assertEquals(AdherenceGrade.GOOD, AdherenceGrade.fromScore(score))
    assertEquals("75-89 Good", AdherenceGrade.fromScore(score).displayTitle)
  }

  @Test
  fun testAdherenceGradeTiers() {
    // 90-100 Excellent
    assertEquals(AdherenceGrade.EXCELLENT, AdherenceGrade.fromScore(95))
    assertEquals(AdherenceGrade.EXCELLENT, AdherenceGrade.fromScore(90))
    assertEquals(AdherenceGrade.EXCELLENT, AdherenceGrade.fromScore(100))
    assertEquals("90-100", AdherenceGrade.EXCELLENT.displayRange)
    assertEquals("90-100 Excellent", AdherenceGrade.EXCELLENT.displayTitle)

    // 75-89 Good
    assertEquals(AdherenceGrade.GOOD, AdherenceGrade.fromScore(89))
    assertEquals(AdherenceGrade.GOOD, AdherenceGrade.fromScore(75))
    assertEquals("75-89", AdherenceGrade.GOOD.displayRange)
    assertEquals("75-89 Good", AdherenceGrade.GOOD.displayTitle)

    // 50-74 Fair
    assertEquals(AdherenceGrade.FAIR, AdherenceGrade.fromScore(74))
    assertEquals(AdherenceGrade.FAIR, AdherenceGrade.fromScore(50))
    assertEquals("50-74", AdherenceGrade.FAIR.displayRange)
    assertEquals("50-74 Fair", AdherenceGrade.FAIR.displayTitle)

    // Below 50 Poor
    assertEquals(AdherenceGrade.POOR, AdherenceGrade.fromScore(49))
    assertEquals(AdherenceGrade.POOR, AdherenceGrade.fromScore(0))
    assertEquals("Below 50", AdherenceGrade.POOR.displayRange)
    assertEquals("Below 50 Poor", AdherenceGrade.POOR.displayTitle)
  }
}
